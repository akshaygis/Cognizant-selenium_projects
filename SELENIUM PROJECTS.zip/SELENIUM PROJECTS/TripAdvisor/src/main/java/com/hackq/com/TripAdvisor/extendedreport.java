package com.hackq.com.TripAdvisor;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
public class extendedreport {
	public static void main(String[] args) throws IOException
	{
	ExtentReports extentreport= new ExtentReports();
	ExtentSparkReporter sparkreporter=new ExtentSparkReporter("report.html");
	extentreport.attachReporter(sparkreporter);
	
	ExtentTest t1=extentreport.createTest("Test 1");
	t1.pass("This is passed");
	
	extentreport.createTest("Test 2").skip("this is skipped");
			
extentreport.flush();
	
	Desktop.getDesktop().browse(new File("report.html").toURI());
	
	
	}
}
