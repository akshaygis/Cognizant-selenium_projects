package com.hackq.com.TripAdvisor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFCell;

public class excelfunction {
	
	

		public FileInputStream fi;
		public FileOutputStream fo;
		public XSSFWorkbook workbook;
		public XSSFSheet sheet;
		public XSSFRow row;
		public XSSFCell cell;
		String path =null;

		
		public excelfunction(String path) throws IOException {
			this.path = path;
		}
		
		public void writedata(String sheetname,int rownum,int colmnum,String [][] data) throws IOException
		{
		
			fi = new FileInputStream(path);
			workbook = new XSSFWorkbook(fi);
			sheet = workbook.getSheet(sheetname);
			
			
			for(int r = 1; r <= rownum; r++)
			{
				row = sheet.createRow(r);
				
				for(int c = 0; c < colmnum; c++)
				{
					cell = row.createCell(c);
					cell.setCellValue(data[r-1][c]);
					//System.out.println("inside the loop");
				}
			}
			
			fo = new FileOutputStream(path);
			workbook.write(fo);
			workbook.close();
			fi.close();
			fo.close();
			System.out.println("Data inserted in Excel file.");	
		}	
		
		public static void main(String[] args) throws IOException
		{
//			String [][] hotelnames={
//					{"new hotel","6754","345"},
//					{"old hotle","987","976bightd"}
//					};
//			
//			excelfunction ex=new excelfunction(".//datafiles//tripadvisor.xlsx");
//			ex.writedata("hotels", 1, 0, hotelnames);
//			
					
		}
	}


